/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Nidurangani
 */
public class ProductModel {

    public void addProduct(String id, String name, String cost, String company, String type, String description) throws SQLException, ClassNotFoundException {
        String sql = "INSERT INTO addproduct (id, productname, cost, company, type, description) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, id);
            pstmt.setString(2, name);
            pstmt.setString(3, cost);
            pstmt.setString(4, company);
            pstmt.setString(5, type);
            pstmt.setString(6, description);
            pstmt.executeUpdate();
        }
    }

    public List<Object[]> getAllProducts() throws SQLException, ClassNotFoundException {
        String sql = "SELECT * FROM addproduct";
        List<Object[]> productList = new ArrayList<>();
        try (Connection conn = connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Object[] product = {
                    rs.getString("id"),
                    rs.getString("productname"),
                    rs.getString("cost"),
                    rs.getString("company"),
                    rs.getString("type"),
                    rs.getString("description")
                };
                productList.add(product);
            }
        }
        return productList;
    }

    private Connection connect() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void product(String id, String name, String cost, String company, String type, String description) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
}
