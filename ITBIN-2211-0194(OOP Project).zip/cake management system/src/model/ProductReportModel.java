/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
/**
 *
 * @author Nidurangani
 */
public class ProductReportModel {
    private Connection conn;

    public ProductReportModel() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.jdbc.Driver");
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/cake management system", "root", "");
    }

    public ResultSet getAllProducts() throws SQLException {
        String sql = "SELECT * FROM addproduct";
        PreparedStatement ptst = conn.prepareStatement(sql);
        return ptst.executeQuery();
    }
}