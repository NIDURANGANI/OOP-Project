/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
/**
 *
 * @author Nidurangani
 */
public class SalesReportModel {
    private Connection conn;

    public SalesReportModel() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.jdbc.Driver");
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/cake management system", "root", "");
    }

    public void addSale(String sid, String customerName, String mobile, String productName, String qty, String price) throws SQLException {
        String sql = "INSERT INTO sales (SID, cname, cmobile, pname, qty, price) VALUES (?, ?, ?, ?, ?, ?)";
        PreparedStatement ptst = conn.prepareStatement(sql);
        ptst.setString(1, sid);
        ptst.setString(2, customerName);
        ptst.setString(3, mobile);
        ptst.setString(4, productName);
        ptst.setString(5, qty);
        ptst.setString(6, price);

        ptst.executeUpdate();
        conn.close();
    }
}
