/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import model.ProductModel;


import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
/**
 *
 * @author Nidurangani
 */
public class ProductReportController {
     private ProductModel model;
    private ProductReportView view;

    public ProductReportController(ProductModel model, ProductReportView view) {
        this.model = model;
        this.view = view;

        this.view.addBackButtonListener(new BackButtonListener());
        this.view.addInsertButtonListener(new InsertButtonListener());
        this.view.addSelectButtonListener(new SelectButtonListener());
        this.view.addLabelClickListener(new LabelClickListener());
    }

    private static class dashboard {

        public dashboard() {
        }
    }

    private static class ProductReportView {

        public ProductReportView() {
        }

        private void addBackButtonListener(BackButtonListener backButtonListener) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        private void addInsertButtonListener(InsertButtonListener insertButtonListener) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        private void addSelectButtonListener(SelectButtonListener selectButtonListener) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        private void addLabelClickListener(LabelClickListener labelClickListener) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        private void dispose() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        private DefaultTableModel getTableModel() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }

    private static class DashboardView {

        public DashboardView() {
        }
    }

    private static class BackButtonListener {

        public BackButtonListener() {
        }
    }

    
    class InsertButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            try {
                ResultSet rs = (ResultSet) model.getAllProducts();
                DefaultTableModel dt = view.getTableModel();
                dt.setRowCount(0);

                while (rs.next()) {
                    Object o[] = {
                        rs.getInt("ID"), rs.getString("Productname"), rs.getInt("cost"),
                        rs.getString("company"), rs.getString("type"), rs.getString("Description")
                    };
                    dt.addRow(o);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, ex);
            }
        }
    }

    class SelectButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            try {
                ResultSet rs = (ResultSet) model.getAllProducts();
                DefaultTableModel dt = view.getTableModel();
                dt.setRowCount(0);

                while (rs.next()) {
                    Object o[] = {
                        rs.getInt("ID"), rs.getString("Productname"), rs.getInt("cost"),
                        rs.getString("company"), rs.getString("type"), rs.getString("Description")
                    };
                    dt.addRow(o);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, ex);
            }
        }
    }

    class LabelClickListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            try {
                ResultSet rs = (ResultSet) model.getAllProducts();
                DefaultTableModel dt = view.getTableModel();
                dt.setRowCount(0);

                while (rs.next()) {
                    Object o[] = {
                        rs.getInt("ID"), rs.getString("Productname"), rs.getInt("cost"),
                        rs.getString("company"), rs.getString("type"), rs.getString("Description")
                    };
                    dt.addRow(o);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, ex);
            }
        }
    }
}
    

