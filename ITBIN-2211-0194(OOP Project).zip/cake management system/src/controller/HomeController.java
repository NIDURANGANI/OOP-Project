/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import view.Home;
import view.Login;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author Nidurangani
 */
public class HomeController {
     private Home view;

    public HomeController(Home view) {
        this.view = view;
      
        
    }

    class NextButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            view.dispose();
            new Login().setVisible(true);  // Assuming LoginView is your login page
        }
    }
}

    class NextButtonListener {

        public NextButtonListener() {
        }
    }

