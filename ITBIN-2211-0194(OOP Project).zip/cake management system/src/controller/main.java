/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import view.Home;
import controller.HomeController;
import view.Login;
import controller.LoginController;

/**
 *
 * @author Nidurangani
 */
public class main {
     public static void main(String[] args) {
        Home view = new Home();
        HomeController controller = new HomeController(view);
        view.setVisible(true);
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
     
     
     
     
     
}
