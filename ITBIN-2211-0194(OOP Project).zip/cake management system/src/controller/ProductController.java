/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import model.ProductModel;
import java.util.List;
/**
 *
 * @author Nidurangani
 */
public class ProductController {
     private ProductModel model;

    public ProductController() {
        model = new ProductModel();
    }

    public void addProduct(String id, String name, String cost, String company, String type, String description) throws Exception {
        model.product(id, name, cost, company, type, description);
    }

    public List<Object[]> getAllProducts() throws Exception {
        return model.getAllProducts();
    }
}
