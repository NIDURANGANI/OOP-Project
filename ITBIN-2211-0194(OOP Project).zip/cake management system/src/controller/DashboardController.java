/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author Nidurangani
 */
public class DashboardController {
      private final DashboardView view;

    public DashboardController(DashboardView view) {
        this.view = view;
        this.view.addAddProductListener(new AddProductListener());
        this.view.addProductReportListener(new ProductReportListener());
        this.view.addAddSalesListener(new AddSalesListener());
        this.view.addSalesReportListener(new SalesReportListener());
        this.view.addExitListener(new ExitListener());
    }
 public void setVisible(boolean visible) {
        view.setVisible(visible);
    }

    private static class Product {

        public Product() {
        }

        private void setVisible(boolean b) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }

    private static class ProductReport {

        public ProductReport() {
        }

        private void setVisible(boolean b) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }

    private static class sales {

        public sales() {
        }

        private void setVisible(boolean b) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }

    private static class SalesReport {

        public SalesReport() {
        }

        private void setVisible(boolean b) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }

    private static class DashboardView {

        public DashboardView() {
        }

        private void dispose() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        private void addAddProductListener(AddProductListener addProductListener) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        private void addProductReportListener(ProductReportListener productReportListener) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        private void addSalesReportListener(SalesReportListener salesReportListener) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        private void addAddSalesListener(AddSalesListener addSalesListener) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        private void addExitListener(ExitListener exitListener) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        private void setVisible(boolean visible) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }

    class AddProductListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            view.dispose();
            // Implement showing the Add Product view
            new Product().setVisible(true);
        }
    }

    class ProductReportListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            view.dispose();
            // Implement showing the Product Report view
            new ProductReport().setVisible(true);
        }
    }

    class AddSalesListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            view.dispose();
            // Implement showing the Add Sales view
            new sales().setVisible(true);
        }
    }

    class SalesReportListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            view.dispose();
            // Implement showing the Sales Report view
            new SalesReport().setVisible(true);
        }  
    }

    class ExitListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            System.exit(0);
        }
    }

}